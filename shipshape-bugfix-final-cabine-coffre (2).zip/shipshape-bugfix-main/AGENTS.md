<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Preserve the uploaded game's module structure and TypeScript compatibility settings to avoid unrelated changes when correcting the existing game.
- Use src/game/world.ts as the shared source of ship geometry, access points, and floor-specific collisions so rendering and movement agree.
- Mount the game at / with SSR disabled because its Three.js scene and controls depend on browser APIs.
- Keep optional multiplayer inactive when no service configuration is available so the imported solo game remains playable without adding a new backend.
