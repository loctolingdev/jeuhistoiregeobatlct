import { useEffect, useRef, useState } from "react";
import { useMp } from "../multiplayer";
import { input } from "../controls";

export function Chat() {
  const { messages, players, connected, chatOpen, unread, name, myId, setChatOpen, sendChat, setName } = useMp();
  const [text, setText] = useState("");
  const [editing, setEditing] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const count = Object.keys(players).length + 1;

  useEffect(() => {
    useMp.getState().connect();
    return () => useMp.getState().disconnect();
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement) return;
      if (e.code === "Enter" || e.code === "KeyT") {
        e.preventDefault();
        input.keys.clear();
        setChatOpen(true);
        setTimeout(() => inputRef.current?.focus(), 0);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [setChatOpen]);

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight });
  }, [messages, chatOpen]);

  if (!chatOpen) {
    return (
      <button className="chat-toggle pointer-events-auto" onClick={() => setChatOpen(true)}>
        💬 Chat <span className="chat-count">{count} en ligne</span>
        {unread > 0 && <span className="chat-badge">{unread}</span>}
      </button>
    );
  }

  return (
    <div className="chat-box pointer-events-auto" onPointerDown={(e) => e.stopPropagation()}>
      <div className="chat-head">
        <span className={connected ? "chat-dot chat-dot--on" : "chat-dot"} />
        <span className="font-display">Le port · {count} en ligne</span>
        <button className="chat-close" onClick={() => setChatOpen(false)} aria-label="Fermer">✕</button>
      </div>
      <div className="chat-who">
        {editing ? (
          <input
            autoFocus
            defaultValue={name}
            maxLength={20}
            className="chat-input"
            onBlur={(e) => {
              setName(e.target.value);
              setEditing(false);
            }}
            onKeyDown={(e) => {
              if (e.key === "Enter") (e.target as HTMLInputElement).blur();
            }}
          />
        ) : (
          <button className="chat-name-btn" onClick={() => setEditing(true)}>
            Vous : <b>{name}</b> ✎
          </button>
        )}
        {Object.values(players).map((p, i) => (
          <span key={i} className="chat-player">{p.name}</span>
        ))}
      </div>
      <div ref={listRef} className="chat-list">
        {messages.length === 0 && <div className="chat-sys">Aucun message. Dites bonjour !</div>}
        {messages.map((m) =>
          m.system ? (
            <div key={m.id} className="chat-sys">{m.text}</div>
          ) : (
            <div key={m.id} className={m.from === myId ? "chat-msg chat-msg--me" : "chat-msg"}>
              <span className="chat-author">{m.name}</span>
              <span>{m.text}</span>
            </div>
          ),
        )}
      </div>
      <form
        className="chat-form"
        onSubmit={(e) => {
          e.preventDefault();
          sendChat(text);
          setText("");
        }}
      >
        <input
          ref={inputRef}
          value={text}
          onChange={(e) => setText(e.target.value)}
          onFocus={() => input.keys.clear()}
          onKeyDown={(e) => {
            if (e.key === "Escape") {
              e.stopPropagation();
              inputRef.current?.blur();
            }
          }}
          placeholder={connected ? "Écrire un message… (Entrée)" : "Connexion…"}
          maxLength={200}
          className="chat-input"
        />
        <button type="submit" className="ui-btn ui-btn--primary" disabled={!text.trim()}>
          Envoyer
        </button>
      </form>
    </div>
  );
}
