# Ship Shape Fix

Voici le fichier zip de mon jeu. corrige le bug de la pancarte bonnaffé sur le bateau en le remettant bien sur le bateau. Quand je vais ds la cale corrige le bug que la cale est a l autre bout de la mapp corrige ce bug. et pour le ponton du bateau mets le bien au niveau de l epace prévu a cette effet. stp

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/fa880a26-e69c-4e00-9270-c58ea98a8ad0).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
